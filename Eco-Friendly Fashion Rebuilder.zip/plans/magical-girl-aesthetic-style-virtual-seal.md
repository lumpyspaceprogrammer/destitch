# Magical Girl Eco-Fashion Transformer — Implementation Plan

## Context
A whimsical, Magical Girl aesthetic app that takes a fast fashion product URL (Shein, Temu, Aliexpress, Amazon), simulates deconstructing the item's toxic/cheap materials, and walks the user through rebuilding a better, eco-friendly handmade version with step-by-step instructions and material substitutions. The image reference (`CUTE_AESTHETICS.jpg`) shows: soft pink/lavender pastel sky, sparkles, holographic iridescent script text — commit fully to this look.

Since there's no backend, the URL is parsed client-side for keywords (dress, jacket, bag, top, jeans) to select from pre-built item templates with realistic material data. This is honest about being a demo while showing the full concept compellingly.

---

## App State Machine
```
idle → analyzing → breakdown → complete
```
- **idle**: hero + URL input
- **analyzing**: animated magical deconstruction sequence (~3s simulated)  
- **breakdown**: material-by-material reveal (original toxic → eco substitute cards), then DIY steps
- **complete**: cost summary, eco impact stats, celebration confetti

---

## Aesthetic (Magical Girl / Kawaii)
Honor the image literally — do NOT use SaaS-modern defaults.

**Design Tokens (theme.css updates):**
- `--background`: `#fce4f6` (dream pink)
- `--foreground`: `#4a1942` (deep plum)
- `--card`: `#fff0fb` (blush white)
- `--primary`: `#d946a8` (hot magenta)
- `--primary-foreground`: `#ffffff`
- `--secondary`: `#e8d5f5` (soft lavender)
- `--secondary-foreground`: `#4a1942`
- `--accent`: `#a855f7` (purple sparkle)
- `--accent-foreground`: `#ffffff`
- `--muted`: `#f5d0ee`
- `--muted-foreground`: `#8b3a7a`
- `--border`: `rgba(217, 70, 168, 0.2)`
- `--radius`: `1rem`

**Fonts (fonts.css):**
- `Pacifico` — display/logo (playful, bubbly cursive)
- `Nunito` — body (rounded, cute, highly readable)

**Decorative layer:**
- Animated sparkle/star elements scattered across the full-page pink→lavender→purple gradient background
- Floating cloud shapes (CSS blur circles, very low opacity) 
- Holographic rainbow shimmer on main title (CSS `background-clip: text` with animated gradient)
- Soft glowing borders on cards (box-shadow with pink tint)
- Sparkle burst animation on "Transform!" button click and phase transitions
- Wand/star spinner during analyzing phase

---

## Item Templates (5 types, selected by URL keyword detection)
Each template has: item name, emoji, original materials array, eco substitutes array, DIY steps array.

### Keyword detection logic
```
url.toLowerCase() →
  dress/skirt/gown → "dress"
  jacket/coat/hoodie → "jacket"
  bag/purse/tote/handbag → "bag"
  top/shirt/blouse/tee → "top"
  jean/pant/trouser/short → "jeans"
  default → rotate through templates based on domain hash
```

### Example — Dress template
**Original materials:**
1. 100% Polyester — microplastic shedding, petroleum-based, non-breathable
2. AZO dyes — carcinogenic, pollutes waterways
3. Cheap polyester thread — snaps easily, unravels
4. Plastic zipper — breaks in months, non-recyclable

**Eco substitutes:**
1. GOTS-certified organic cotton or linen blend — breathable, biodegradable, ~$8–12/yd
2. Low-impact fiber-reactive dyes or natural dyes (turmeric, indigo) — non-toxic, ~$5–15/kit
3. 100% cotton or linen thread — durable, biodegradable, ~$3/spool
4. YKK brass or recycled nylon zipper — decades lifespan, ~$2–4 each

**DIY Steps:** (7–9 steps: measure → cut → dye → sew seams → insert zipper → hem → press)

*(Jacket, Bag, Top, Jeans templates follow same structure)*

---

## Component Structure (all in App.tsx)

### Layout layers
1. `SparkleBackground` — fixed full-screen animated stars (CSS keyframes, 20–30 pseudo-elements via JS array)
2. `App` — state machine controller, phase transitions

### Phase components
3. `HeroSection` — logo title with holographic shimmer, tagline, URL input, "✨ Transform It!" button
4. `AnalyzingAnimation` — wand spinning, staggered text messages ("Detecting materials…", "Scanning for toxins…", "Summoning eco alternatives…"), progress bar
5. `BreakdownSection`
   - `ItemHeader` — item type badge, emoji, name, original price vs estimated DIY cost
   - `MaterialSwapCard` × N — flippable/revealed card: left = original (red-tinted, ☠️ icon, why bad), right = eco substitute (green-tinted, ✨ icon, why good, where to buy, approx cost). Cards reveal one by one with staggered animation
   - `DividerSparkle` — decorative section break
   - `StepsList` — numbered DIY steps with icons, each step has tool emoji + instruction
6. `SummaryPanel` — eco impact stats (plastic saved, water saved, CO₂ avoided), cost comparison table, "Save My Pattern ⭐" button (downloads as text), celebration message

### Utility hooks
- `useItemTemplate(url: string)` — returns detected item template
- `usePhaseTransition()` — manages the state machine with timers

---

## Files to Modify
- `src/app/App.tsx` — full replacement with complete implementation
- `src/styles/theme.css` — update `:root` token values (preserve structure + `.dark` block + `@theme inline`)
- `src/styles/fonts.css` — add Google Fonts import for Pacifico + Nunito

## Files to Read (already done)
- `src/app/App.tsx` ✓
- `src/styles/theme.css` ✓
- `src/styles/fonts.css` ✓
- `src/imports/CUTE_AESTHETICS.jpg` ✓ (aesthetic reference)

## Available UI components to reuse
From `/src/app/components/ui/`: `Button`, `Input`, `Card`, `Badge`, `Progress`, `Tabs` — use sparingly where they fit the magical girl style (may need className overrides for pink theming).

`ImageWithFallback` at `/src/app/components/figma/ImageWithFallback.tsx` — not needed (no images to embed).

---

## Verification
1. App loads with full pink/lavender sparkle background and holographic title
2. Enter a URL like `https://www.shein.com/floral-dress-p-123.html` → "dress" template selected
3. Analyzing animation plays for ~3s with staggered messages
4. Material swap cards reveal one by one with animations
5. DIY steps list appears after all cards revealed
6. Summary panel shows cost/eco stats
7. Test with `temu.com/tote-bag` → bag template, `aliexpress.com/jacket` → jacket template
8. Responsive: stacks gracefully on mobile (cards go full-width, steps stay readable)
