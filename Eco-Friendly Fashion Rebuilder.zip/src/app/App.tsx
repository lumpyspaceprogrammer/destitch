import { useState, useEffect, useRef } from "react";

// ─── Types ────────────────────────────────────────────────────────────────────

interface Material {
  name: string;
  why: string;
  icon: string;
}

interface EcoMaterial {
  name: string;
  why: string;
  source: string;
  cost: string;
  icon: string;
}

interface Step {
  emoji: string;
  title: string;
  detail: string;
}

interface ItemTemplate {
  type: string;
  emoji: string;
  name: string;
  originalPrice: string;
  diyPrice: string;
  plasticSaved: string;
  waterSaved: string;
  co2Avoided: string;
  materials: Material[];
  ecoMaterials: EcoMaterial[];
  steps: Step[];
}

// ─── Item Templates ───────────────────────────────────────────────────────────

const TEMPLATES: Record<string, ItemTemplate> = {
  dress: {
    type: "dress",
    emoji: "👗",
    name: "Floral Mini Dress",
    originalPrice: "$14.99",
    diyPrice: "$28–38",
    plasticSaved: "~190g",
    waterSaved: "~2,700L",
    co2Avoided: "~3.6kg",
    materials: [
      { name: "100% Polyester fabric", why: "Petroleum-derived, sheds microplastics every wash, takes 200+ years to decompose.", icon: "☠️" },
      { name: "AZO synthetic dyes", why: "Linked to carcinogens, pollutes rivers near dye factories, harmful to garment workers.", icon: "🧪" },
      { name: "Cheap polyester thread", why: "Snaps within months, causes seam failure, not biodegradable.", icon: "💀" },
      { name: "Plastic invisible zipper", why: "Breaks easily, cannot be recycled, ends up in landfill.", icon: "🗑️" },
    ],
    ecoMaterials: [
      { name: "GOTS-certified organic cotton or linen", why: "Breathable, biodegradable, grown without pesticides.", source: "Mood Fabrics, Fabric.com, local fabric shops", cost: "$8–12/yd", icon: "🌿" },
      { name: "Low-impact fiber-reactive or natural dyes", why: "Non-toxic, safe for waterways, beautiful earthy tones. Try turmeric, indigo, or avocado pits!", source: "Dharma Trading Co., Earthues", cost: "$5–15/kit", icon: "🎨" },
      { name: "100% cotton or linen thread", why: "Durable, fully biodegradable, holds seams for decades.", source: "Gutermann, Coats & Clark", cost: "$3–5/spool", icon: "🌱" },
      { name: "YKK brass or recycled nylon zipper", why: "YKK zippers last decades. Brass is fully recyclable at end of life.", source: "Zipit, Amazon (search YKK brass)", cost: "$2–4 each", icon: "✨" },
    ],
    steps: [
      { emoji: "📏", title: "Take your measurements", detail: "Measure bust, waist, hips, and desired length. Add 1.5\" seam allowance on all sides." },
      { emoji: "✂️", title: "Cut your fabric", detail: "Cut front bodice, back bodice, and skirt panels. Pre-wash fabric first to prevent shrinkage." },
      { emoji: "🎨", title: "Dye if desired", detail: "Simmer fabric in your natural dye bath for 45–60 min. Fix with alum mordant for colorfastness." },
      { emoji: "🪡", title: "Sew the bodice darts", detail: "Pin and sew bust darts on front piece for shape. Press flat with iron." },
      { emoji: "👕", title: "Join bodice pieces", detail: "Sew front to back at shoulder seams. Press open. Repeat for side seams, leaving right side open for zipper." },
      { emoji: "🔗", title: "Attach skirt to bodice", detail: "Gather skirt panels if desired. Pin to bodice at waist, right sides together. Sew with a ⅝\" seam." },
      { emoji: "🤐", title: "Insert the zipper", detail: "Hand-baste zipper along right side seam opening. Sew with zipper foot, starting from the bottom." },
      { emoji: "📐", title: "Hem the dress", detail: "Fold hem up ½\" then 1\". Press and topstitch or slipstitch by hand for an invisible hem." },
      { emoji: "🌟", title: "Press and admire!", detail: "Give the whole dress a steam press. Try it on — you made something that will last years, not weeks!" },
    ],
  },
  jacket: {
    type: "jacket",
    emoji: "🧥",
    name: "Oversized Utility Jacket",
    originalPrice: "$29.99",
    diyPrice: "$45–65",
    plasticSaved: "~310g",
    waterSaved: "~1,800L",
    co2Avoided: "~5.2kg",
    materials: [
      { name: "Acrylic/polyester blend shell", why: "Acrylic is essentially plastic — it pills, sheds microfibres, and never biodegrades.", icon: "☠️" },
      { name: "Polyester batting insulation", why: "Non-breathable, loses loft after washing, microplastic shedder.", icon: "🧪" },
      { name: "Plastic snap buttons", why: "Snap buttons crack with use, crack off, and cannot be repaired or recycled.", icon: "💀" },
      { name: "Nylon lining with formaldehyde finish", why: "Formaldehyde finish off-gases on skin, causes dermatitis in sensitive people.", icon: "🗑️" },
    ],
    ecoMaterials: [
      { name: "Organic canvas or deadstock denim", why: "Durable, structured, biodegradable. Deadstock reuses existing fabric waste.", source: "Fabscrap (NYC), Queen of Raw, local thrift for deadstock", cost: "$10–18/yd", icon: "🌿" },
      { name: "Organic wool batting or Tencel fill", why: "Wool is naturally temperature-regulating and fire-resistant. Tencel is closed-loop production.", source: "Loom & Field, Simplifi Fabric", cost: "$12–20/yd", icon: "🐑" },
      { name: "Recycled brass or vintage snaps", why: "Brass snaps last a lifetime and can be re-set if they come loose.", source: "Etsy (vintage snaps), Rocky Mountain Fabric", cost: "$6–10/set of 10", icon: "✨" },
      { name: "Organic cotton or Tencel lining", why: "Breathes well against skin, no toxic finishing chemicals.", source: "Dharma Trading, Organic Cotton Plus", cost: "$7–11/yd", icon: "🌱" },
    ],
    steps: [
      { emoji: "📏", title: "Draft your pattern", detail: "Use a well-fitting jacket you own as a template. Trace onto pattern paper, adding 1\" seam allowance." },
      { emoji: "✂️", title: "Cut shell & lining", detail: "Cut outer shell pieces and lining pieces separately. Mark all notches." },
      { emoji: "🪡", title: "Construct the shell", detail: "Sew shell side seams and shoulder seams. Press all seams open with a clapper for crisp edges." },
      { emoji: "🔗", title: "Set the sleeves", detail: "Ease sleeve cap into armhole and pin at 1\" intervals before sewing to prevent puckers." },
      { emoji: "🧵", title: "Construct the lining", detail: "Sew lining in same order as shell, but leave an 8\" gap at lower back hem for turning." },
      { emoji: "🔘", title: "Attach pockets", detail: "For patch pockets: topstitch onto shell front before joining lining. For welt pockets: cut and bind pocket openings." },
      { emoji: "👔", title: "Join shell and lining", detail: "Place shell and lining right sides together. Sew around front edges and hem. Turn through gap. Slip-stitch gap closed." },
      { emoji: "📌", title: "Set the snaps", detail: "Mark snap positions. Use a snap-setter tool — no sewing required. Test each snap before finishing." },
      { emoji: "🌟", title: "Topstitch and press", detail: "Topstitch ⅛\" from all edges for a polished finish. Steam press thoroughly." },
    ],
  },
  bag: {
    type: "bag",
    emoji: "👜",
    name: "Trendy Tote / Crossbody Bag",
    originalPrice: "$12.99",
    diyPrice: "$18–30",
    plasticSaved: "~240g",
    waterSaved: "~900L",
    co2Avoided: "~2.1kg",
    materials: [
      { name: "PU (faux leather) exterior", why: "Peels within 6–12 months, made from polyurethane (plastic), microplastic shedder, impossible to repair.", icon: "☠️" },
      { name: "Polyester lining", why: "Stains easily, non-breathable, sheds microfibres.", icon: "🧪" },
      { name: "Zinc alloy (mystery metal) hardware", why: "Tarnishes quickly, often contains lead/cadmium, breaks under light stress.", icon: "💀" },
      { name: "Chemical glue construction", why: "Glued seams delaminate in heat or rain. No stitching means no repairability.", icon: "🗑️" },
    ],
    ecoMaterials: [
      { name: "Cork fabric or natural canvas", why: "Cork is harvested without harming trees, water-resistant, beautiful grain. Canvas ages beautifully.", source: "Corkor, Fabric.com, Canvas ETC", cost: "$12–20/yd", icon: "🌿" },
      { name: "Organic cotton twill lining", why: "Easy to clean, breathable, fully biodegradable.", source: "Organic Cotton Plus, Etsy fabric sellers", cost: "$6–9/yd", icon: "🌱" },
      { name: "Solid brass or recycled steel hardware", why: "Brass develops a gorgeous patina and lasts decades. Recycled steel has 75% lower footprint.", source: "Buckleguy.com, Weaver Leather Supply", cost: "$8–15/set", icon: "✨" },
      { name: "Waxed linen thread (saddle-stitched)", why: "Hand saddle-stitching is stronger than machine stitching — if one stitch breaks, it won't run.", source: "Tandy Leather, Thread Exchange", cost: "$4–8/spool", icon: "🪡" },
    ],
    steps: [
      { emoji: "📏", title: "Design your bag", detail: "Decide on size. A classic tote: 15\"W × 14\"H × 4\"D. Draw pattern pieces on paper." },
      { emoji: "✂️", title: "Cut all pieces", detail: "Cut exterior, lining, pocket pieces, and strap. Interface the exterior with a firm fusible for structure." },
      { emoji: "🪡", title: "Sew the exterior pockets", detail: "Topstitch any outer patch pockets onto the main panel before assembling the bag body." },
      { emoji: "👜", title: "Assemble exterior", detail: "Sew side seams. Box the corners by pinching the bottom corner flat, measuring 2\" from the tip, and sewing across." },
      { emoji: "📬", title: "Make the lining", detail: "Sew lining the same way but leave a 5\" gap at the bottom seam. Add an interior zipper pocket using a 7\" zipper." },
      { emoji: "🔗", title: "Attach hardware", detail: "Install D-rings for the strap using fabric loops. Use a mallet and hole punch to set rivets if using metal construction." },
      { emoji: "🔗", title: "Join exterior and lining", detail: "Place right sides together at the top opening. Sew around the entire top edge. Turn through the gap." },
      { emoji: "🌟", title: "Topstitch the top edge", detail: "Edgestitch ¼\" around the top opening for structure. Slip-stitch the lining gap closed." },
      { emoji: "🎀", title: "Attach the strap", detail: "Clip strap to D-rings with swivel hooks for adjustability. Your bag is done — it will outlast ten Temu bags!" },
    ],
  },
  top: {
    type: "top",
    emoji: "👚",
    name: "Flowy Cropped Blouse",
    originalPrice: "$9.99",
    diyPrice: "$20–32",
    plasticSaved: "~120g",
    waterSaved: "~2,100L",
    co2Avoided: "~2.8kg",
    materials: [
      { name: "Viscose rayon (chemical-heavy)", why: "Conventional rayon uses carbon disulfide — a toxic solvent. Often sourced from endangered forests.", icon: "☠️" },
      { name: "Elastane (spandex) blend", why: "Spandex cannot be separated for recycling, making blended fabrics nearly impossible to recycle.", icon: "🧪" },
      { name: "Synthetic lace trim", why: "Nylon lace sheds microfibres and has no end-of-life pathway.", icon: "💀" },
      { name: "Heat-transfer printed graphic", why: "PVC-based heat transfer vinyl cracks, peels, and off-gases phthalates when heated.", icon: "🗑️" },
    ],
    ecoMaterials: [
      { name: "LENZING™ TENCEL™ or Modal", why: "Closed-loop lyocell process — 99% of solvents recycled. Silky drape, biodegradable.", source: "Mood Fabrics, Fabric.com (search Tencel)", cost: "$9–14/yd", icon: "🌿" },
      { name: "Pure linen or organic cotton voile", why: "Natural stretch with ease allowance. No elastane needed for a flowy top.", source: "Linen Club, Organic Cotton Plus", cost: "$7–12/yd", icon: "🌱" },
      { name: "Cotton or antique lace trim", why: "Natural cotton lace is biodegradable. Vintage/antique lace is upcycled textile waste.", source: "Etsy (vintage lace), fabric stores", cost: "$2–6/yd", icon: "🎀" },
      { name: "Discharge printing or block printing", why: "Water-based inks are non-toxic. Block printing uses zero energy beyond your hands.", source: "Speedball inks, local art supply store", cost: "$10–20/kit", icon: "🖨️" },
    ],
    steps: [
      { emoji: "📏", title: "Choose your silhouette", detail: "Measure bust and desired length. A flowy top needs 2–4\" ease at the bust. Draft a simple rectangle-based pattern." },
      { emoji: "✂️", title: "Cut fabric pieces", detail: "Cut front, back, and sleeve pieces. Tencel frays easily — finish edges immediately with a serger or zigzag stitch." },
      { emoji: "🪡", title: "Sew shoulder seams", detail: "Join front to back at shoulders with a French seam for a clean finish inside and out." },
      { emoji: "👕", title: "Attach sleeves (optional)", detail: "For flutter sleeves, gather the sleeve head before attaching. Or leave armhole open and hem for a sleeveless look." },
      { emoji: "🧵", title: "Sew side seams", detail: "Close side seams with French seams. Leave a 6\" slit at the hem sides for a high-low look if desired." },
      { emoji: "🎀", title: "Attach lace trim", detail: "Pin cotton lace along neckline or hem. Topstitch with matching thread using a narrow zigzag." },
      { emoji: "🖨️", title: "Print your design (optional)", detail: "Use a carved eraser as a block print stamp. Apply ink and stamp onto dry fabric. Heat-set with iron." },
      { emoji: "📐", title: "Hem the blouse", detail: "Roll hem ¼\" twice and press. Topstitch or hand-stitch. For a professional edge, use a serger rolled hem." },
      { emoji: "🌟", title: "Steam and wear!", detail: "Tencel responds beautifully to steam. Press lightly and enjoy a top that gets softer with every wash." },
    ],
  },
  jeans: {
    type: "jeans",
    emoji: "👖",
    name: "Slim Straight-Leg Jeans",
    originalPrice: "$19.99",
    diyPrice: "$35–55",
    plasticSaved: "~280g",
    waterSaved: "~7,500L",
    co2Avoided: "~8.1kg",
    materials: [
      { name: "Conventional cotton denim (pesticide-heavy)", why: "Conventional cotton uses 16% of global insecticides. Single pair uses ~7,500L water to produce.", icon: "☠️" },
      { name: "Synthetic indigo dye", why: "Petroleum-derived synthetic indigo pollutes rivers; conventional dyeing wastewater is highly toxic.", icon: "🧪" },
      { name: "Plastic rivets and buttons", why: "Cheap zinc alloy/plastic rivets corrode and snap, making jeans unrepairable.", icon: "💀" },
      { name: "Sandblasting distressing finish", why: "Sandblasting causes silicosis (fatal lung disease) in factory workers. The dust is lethal.", icon: "🗑️" },
    ],
    ecoMaterials: [
      { name: "Organic selvedge denim", why: "GOTS-certified, woven on old narrow looms — tighter weave means more durable and less water used.", source: "Cone Denim (White Oak), Nihon Menpu, local Japanese denim importers", cost: "$18–35/yd", icon: "🌿" },
      { name: "Natural indigo or plant-based dye", why: "True natural indigo is grown as a crop and fully biodegradable. Your jeans will fade beautifully and uniquely.", source: "Stony Creek Colors, Wild Fibres (UK)", cost: "$15–25/kit", icon: "💙" },
      { name: "Solid copper or brass rivets and buttons", why: "Copper rivets are the original Levi Strauss innovation — they outlast the denim itself.", source: "Tandy Leather, Buckleguy.com", cost: "$8–14/set", icon: "✨" },
      { name: "Hand-distressing with sandpaper", why: "Sand by hand exactly where YOU wear through denim naturally. Zero silica dust, totally safe.", source: "Any hardware store", cost: "$2–4", icon: "🛠️" },
    ],
    steps: [
      { emoji: "📏", title: "Take detailed measurements", detail: "Measure waist, hips, inseam, thigh, knee, and ankle. Jeans need precise fitting — take 5–7 measurements." },
      { emoji: "📐", title: "Draft or trace your pattern", detail: "Use a pair of well-fitting jeans as a sloper. Trace each piece flat on pattern paper. Add ¾\" seam allowances." },
      { emoji: "✂️", title: "Cut your denim", detail: "Cut with the grain. Mark all notches and grain lines. Denim is heavy — use sharp scissors or a rotary cutter." },
      { emoji: "🪡", title: "Sew the fly front", detail: "The fly is the trickiest part. Interface the fly facing. Topstitch the characteristic J-shape with contrasting thread." },
      { emoji: "🧵", title: "Join inseams and outseams", detail: "Sew inseams first, then outseams. Fell the inseam by trimming one seam allowance and folding over the other for durability." },
      { emoji: "🔗", title: "Attach belt loops and waistband", detail: "Make 6 belt loops from a fabric strip. Pin evenly. Attach waistband, checking fit before final sewing." },
      { emoji: "🔘", title: "Set copper rivets and button", detail: "Use a hammer and rivet setter at pocket corners. Set the waistband button through a sewn buttonhole." },
      { emoji: "💙", title: "Dye with natural indigo", detail: "Dip-dye pre-reduced indigo vat for unique fading. Each dip + oxidation cycle deepens the color." },
      { emoji: "🌟", title: "Hem and distress by hand", detail: "Hem to your preferred length. Lightly sand knees and pocket edges with 120-grit sandpaper for authentic fading." },
    ],
  },
};

// ─── URL Detection ────────────────────────────────────────────────────────────

function detectTemplate(url: string): ItemTemplate {
  const u = url.toLowerCase();
  if (u.includes("dress") || u.includes("skirt") || u.includes("gown") || u.includes("frock")) return TEMPLATES.dress;
  if (u.includes("jacket") || u.includes("coat") || u.includes("hoodie") || u.includes("blazer")) return TEMPLATES.jacket;
  if (u.includes("bag") || u.includes("purse") || u.includes("tote") || u.includes("handbag") || u.includes("clutch")) return TEMPLATES.bag;
  if (u.includes("top") || u.includes("shirt") || u.includes("blouse") || u.includes("tee") || u.includes("cami")) return TEMPLATES.top;
  if (u.includes("jean") || u.includes("pant") || u.includes("trouser") || u.includes("denim") || u.includes("short")) return TEMPLATES.jeans;
  // deterministic fallback by domain
  const keys = Object.keys(TEMPLATES);
  const hash = [...url].reduce((acc, c) => acc + c.charCodeAt(0), 0);
  return TEMPLATES[keys[hash % keys.length]];
}

// ─── Sparkle Background ───────────────────────────────────────────────────────

const SPARKLES = Array.from({ length: 28 }, (_, i) => ({
  id: i,
  left: `${(i * 37 + 11) % 100}%`,
  top: `${(i * 53 + 7) % 100}%`,
  size: `${8 + (i % 5) * 4}px`,
  delay: `${(i * 0.4) % 3}s`,
  duration: `${2 + (i % 4) * 0.7}s`,
}));

function SparkleBackground() {
  return (
    <div className="fixed inset-0 pointer-events-none overflow-hidden" style={{ zIndex: 0 }}>
      <div
        className="absolute inset-0"
        style={{
          background: "linear-gradient(135deg, #ff9dd8 0%, #e879f9 30%, #c084fc 60%, #a78bfa 100%)",
        }}
      />
      {/* Cloud blobs */}
      {[
        { w: 320, h: 160, left: "-5%", top: "5%", opacity: 0.25 },
        { w: 260, h: 120, left: "60%", top: "2%", opacity: 0.2 },
        { w: 200, h: 100, left: "20%", top: "75%", opacity: 0.18 },
        { w: 300, h: 140, left: "70%", top: "70%", opacity: 0.2 },
      ].map((c, i) => (
        <div
          key={i}
          className="absolute rounded-full"
          style={{
            width: c.w,
            height: c.h,
            left: c.left,
            top: c.top,
            background: "rgba(255,255,255,0.9)",
            filter: "blur(32px)",
            opacity: c.opacity,
          }}
        />
      ))}
      {/* Stars / sparkles */}
      {SPARKLES.map((s) => (
        <div
          key={s.id}
          className="absolute"
          style={{
            left: s.left,
            top: s.top,
            width: s.size,
            height: s.size,
            animationName: "sparkle-twinkle",
            animationDuration: s.duration,
            animationDelay: s.delay,
            animationIterationCount: "infinite",
            animationTimingFunction: "ease-in-out",
          }}
        >
          <svg viewBox="0 0 24 24" fill="white" style={{ width: "100%", height: "100%", opacity: 0.85 }}>
            <path d="M12 2 L13.5 10.5 L22 12 L13.5 13.5 L12 22 L10.5 13.5 L2 12 L10.5 10.5 Z" />
          </svg>
        </div>
      ))}
    </div>
  );
}

// ─── Hero Section ─────────────────────────────────────────────────────────────

interface HeroSectionProps {
  url: string;
  setUrl: (v: string) => void;
  onSubmit: () => void;
  error: string;
}

function HeroSection({ url, setUrl, onSubmit, error }: HeroSectionProps) {
  const handleKey = (e: React.KeyboardEvent) => {
    if (e.key === "Enter") onSubmit();
  };

  return (
    <div className="flex flex-col items-center gap-8 px-4 py-16 text-center relative z-10">
      {/* Logo wand */}
      <div
        className="text-6xl"
        style={{
          animationName: "wand-float",
          animationDuration: "3s",
          animationIterationCount: "infinite",
          animationTimingFunction: "ease-in-out",
        }}
      >
        🪄
      </div>

      {/* Holographic title */}
      <h1
        className="text-5xl sm:text-7xl leading-tight"
        style={{
          fontFamily: "'Pacifico', cursive",
          background: "linear-gradient(90deg, #ff6eb4, #ff9bd2, #c084fc, #818cf8, #34d399, #fde68a, #ff6eb4)",
          backgroundSize: "300% 100%",
          WebkitBackgroundClip: "text",
          WebkitTextFillColor: "transparent",
          backgroundClip: "text",
          animationName: "holographic-shift",
          animationDuration: "4s",
          animationIterationCount: "infinite",
          animationTimingFunction: "linear",
          filter: "drop-shadow(0 0 12px rgba(217,70,168,0.5))",
        }}
      >
        Stitch & Switch
      </h1>

      <p
        className="text-lg sm:text-xl max-w-xl text-white"
        style={{
          fontFamily: "'Nunito', sans-serif",
          fontWeight: 700,
          textShadow: "0 1px 8px rgba(100,0,80,0.4)",
        }}
      >
        Paste a fast-fashion link ✨ and your magical guide will deconstruct it, expose the toxic shortcuts, and show you how to handcraft a version that actually lasts.
      </p>

      {/* Input area */}
      <div className="w-full max-w-lg flex flex-col gap-3">
        <div
          className="flex rounded-2xl overflow-hidden shadow-xl"
          style={{ background: "rgba(255,255,255,0.25)", backdropFilter: "blur(12px)", border: "2px solid rgba(255,255,255,0.5)" }}
        >
          <input
            type="url"
            value={url}
            onChange={(e) => setUrl(e.target.value)}
            onKeyDown={handleKey}
            placeholder="Paste a Shein, Temu, AliExpress, or Amazon link…"
            className="flex-1 px-4 py-4 bg-transparent text-white placeholder-white/60 outline-none text-sm sm:text-base"
            style={{ fontFamily: "'Nunito', sans-serif", fontWeight: 600 }}
          />
          <button
            onClick={onSubmit}
            className="px-6 py-4 font-bold text-white transition-all hover:scale-105 active:scale-95 whitespace-nowrap"
            style={{
              fontFamily: "'Nunito', sans-serif",
              fontWeight: 800,
              background: "linear-gradient(135deg, #d946a8, #a855f7)",
              fontSize: "0.9rem",
            }}
          >
            ✨ Transform It!
          </button>
        </div>
        {error && (
          <p className="text-red-200 text-sm font-semibold" style={{ fontFamily: "'Nunito', sans-serif" }}>
            {error}
          </p>
        )}
        <p className="text-white/60 text-xs" style={{ fontFamily: "'Nunito', sans-serif" }}>
          Try: shein.com/floral-dress · temu.com/tote-bag · aliexpress.com/jacket
        </p>
      </div>

      {/* Feature pills */}
      <div className="flex flex-wrap gap-3 justify-center mt-2">
        {["🌱 Eco materials", "💰 Affordable DIY", "♻️ Zero microplastics", "💪 Built to last"].map((pill) => (
          <span
            key={pill}
            className="px-4 py-2 rounded-full text-sm font-bold text-white"
            style={{
              fontFamily: "'Nunito', sans-serif",
              background: "rgba(255,255,255,0.2)",
              backdropFilter: "blur(8px)",
              border: "1px solid rgba(255,255,255,0.4)",
            }}
          >
            {pill}
          </span>
        ))}
      </div>
    </div>
  );
}

// ─── Analyzing Animation ──────────────────────────────────────────────────────

const ANALYZING_MESSAGES = [
  "🔍 Scanning product link…",
  "🧬 Detecting fabric composition…",
  "☠️ Identifying toxic materials…",
  "🌍 Calculating environmental impact…",
  "✨ Summoning eco alternatives…",
  "🪡 Preparing your DIY blueprint…",
  "🌟 Almost ready!",
];

function AnalyzingAnimation({ progress }: { progress: number }) {
  const msgIndex = Math.min(Math.floor((progress / 100) * ANALYZING_MESSAGES.length), ANALYZING_MESSAGES.length - 1);

  return (
    <div className="flex flex-col items-center gap-8 px-4 py-20 text-center relative z-10">
      {/* Spinning wand */}
      <div
        className="text-7xl"
        style={{
          animationName: "wand-spin",
          animationDuration: "1.2s",
          animationIterationCount: "infinite",
          animationTimingFunction: "linear",
        }}
      >
        🪄
      </div>

      <h2
        className="text-3xl text-white font-bold"
        style={{ fontFamily: "'Pacifico', cursive", textShadow: "0 2px 12px rgba(100,0,80,0.5)" }}
      >
        Magical Analysis in Progress…
      </h2>

      <p
        className="text-xl text-white/90 font-semibold min-h-[2rem] transition-all duration-500"
        style={{ fontFamily: "'Nunito', sans-serif" }}
      >
        {ANALYZING_MESSAGES[msgIndex]}
      </p>

      {/* Progress bar */}
      <div className="w-full max-w-sm">
        <div
          className="h-4 rounded-full overflow-hidden"
          style={{ background: "rgba(255,255,255,0.25)", border: "1px solid rgba(255,255,255,0.4)" }}
        >
          <div
            className="h-full rounded-full transition-all duration-300"
            style={{
              width: `${progress}%`,
              background: "linear-gradient(90deg, #ff6eb4, #c084fc, #818cf8)",
              boxShadow: "0 0 16px rgba(192,132,252,0.8)",
            }}
          />
        </div>
        <p className="text-white/70 text-sm mt-2" style={{ fontFamily: "'Nunito', sans-serif" }}>
          {Math.round(progress)}%
        </p>
      </div>
    </div>
  );
}

// ─── Material Swap Card ───────────────────────────────────────────────────────

interface MaterialSwapCardProps {
  original: Material;
  eco: EcoMaterial;
  visible: boolean;
  index: number;
}

function MaterialSwapCard({ original, eco, visible, index }: MaterialSwapCardProps) {
  return (
    <div
      className="w-full transition-all duration-700"
      style={{
        opacity: visible ? 1 : 0,
        transform: visible ? "translateY(0)" : "translateY(24px)",
        transitionDelay: `${index * 120}ms`,
        fontFamily: "'Nunito', sans-serif",
      }}
    >
      <div
        className="rounded-2xl overflow-hidden shadow-lg"
        style={{ border: "1px solid rgba(217,70,168,0.2)" }}
      >
        {/* Header row */}
        <div className="grid grid-cols-2">
          {/* Original / bad */}
          <div
            className="p-4"
            style={{ background: "linear-gradient(135deg, #fff0f0, #ffe4e4)" }}
          >
            <div className="flex items-center gap-2 mb-2">
              <span className="text-2xl">{original.icon}</span>
              <span className="text-xs font-bold uppercase tracking-wider text-red-500">Original</span>
            </div>
            <p className="font-bold text-sm text-red-800 mb-1">{original.name}</p>
            <p className="text-xs text-red-600 leading-snug">{original.why}</p>
          </div>

          {/* Arrow */}
          <div className="hidden" />
        </div>

        {/* Eco replacement */}
        <div
          className="p-4"
          style={{ background: "linear-gradient(135deg, #f0fdf4, #dcfce7)", borderTop: "2px solid rgba(217,70,168,0.15)" }}
        >
          <div className="flex items-center gap-2 mb-2">
            <span className="text-2xl">{eco.icon}</span>
            <span className="text-xs font-bold uppercase tracking-wider text-emerald-600">✨ Eco Swap</span>
            <span className="ml-auto text-xs font-bold text-emerald-700 bg-emerald-100 px-2 py-0.5 rounded-full">
              {eco.cost}
            </span>
          </div>
          <p className="font-bold text-sm text-emerald-900 mb-1">{eco.name}</p>
          <p className="text-xs text-emerald-700 leading-snug mb-1">{eco.why}</p>
          <p className="text-xs text-emerald-500">
            <span className="font-semibold">Where to find:</span> {eco.source}
          </p>
        </div>
      </div>
    </div>
  );
}

// ─── DIY Steps ────────────────────────────────────────────────────────────────

function StepsList({ steps, visible }: { steps: Step[]; visible: boolean }) {
  return (
    <div className="flex flex-col gap-4" style={{ fontFamily: "'Nunito', sans-serif" }}>
      {steps.map((step, i) => (
        <div
          key={i}
          className="flex gap-4 items-start transition-all duration-500"
          style={{
            opacity: visible ? 1 : 0,
            transform: visible ? "translateX(0)" : "translateX(-16px)",
            transitionDelay: visible ? `${i * 80}ms` : "0ms",
          }}
        >
          <div
            className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-lg font-black text-white shadow-md"
            style={{ background: "linear-gradient(135deg, #d946a8, #a855f7)" }}
          >
            {i + 1}
          </div>
          <div
            className="flex-1 rounded-xl p-4 shadow-sm"
            style={{
              background: "rgba(255,255,255,0.7)",
              backdropFilter: "blur(8px)",
              border: "1px solid rgba(217,70,168,0.15)",
            }}
          >
            <div className="flex items-center gap-2 mb-1">
              <span className="text-xl">{step.emoji}</span>
              <h4 className="font-bold text-sm" style={{ color: "#4a1942" }}>{step.title}</h4>
            </div>
            <p className="text-sm leading-relaxed" style={{ color: "#8b3a7a" }}>{step.detail}</p>
          </div>
        </div>
      ))}
    </div>
  );
}

// ─── Summary Panel ────────────────────────────────────────────────────────────

function SummaryPanel({ item, onReset }: { item: ItemTemplate; onReset: () => void }) {
  const handleSave = () => {
    const lines = [
      `✨ STITCH & SWITCH — ${item.name.toUpperCase()} PATTERN`,
      `Generated by Stitch & Switch\n`,
      "═══ ECO MATERIALS ═══",
      ...item.ecoMaterials.map((m, i) => `${i + 1}. ${m.name}\n   ${m.source}\n   Cost: ${m.cost}`),
      "\n═══ DIY STEPS ═══",
      ...item.steps.map((s, i) => `Step ${i + 1}: ${s.title}\n${s.detail}`),
      `\n💚 You saved: ${item.plasticSaved} plastic | ${item.waterSaved} water | ${item.co2Avoided} CO₂`,
    ];
    const blob = new Blob([lines.join("\n\n")], { type: "text/plain" });
    const a = document.createElement("a");
    a.href = URL.createObjectURL(blob);
    a.download = `stitch-switch-${item.type}-pattern.txt`;
    a.click();
  };

  return (
    <div
      className="rounded-3xl p-6 sm:p-8 shadow-2xl"
      style={{
        fontFamily: "'Nunito', sans-serif",
        background: "rgba(255,255,255,0.25)",
        backdropFilter: "blur(16px)",
        border: "2px solid rgba(255,255,255,0.5)",
      }}
    >
      <div className="text-center mb-6">
        <div className="text-5xl mb-3">🌟</div>
        <h3
          className="text-2xl text-white mb-1"
          style={{ fontFamily: "'Pacifico', cursive", textShadow: "0 2px 10px rgba(100,0,80,0.4)" }}
        >
          Transformation Complete!
        </h3>
        <p className="text-white/80 text-sm font-semibold">Your eco-friendly {item.name} blueprint is ready ✨</p>
      </div>

      {/* Stats */}
      <div className="grid grid-cols-3 gap-3 mb-6">
        {[
          { label: "Plastic saved", value: item.plasticSaved, emoji: "♻️" },
          { label: "Water saved", value: item.waterSaved, emoji: "💧" },
          { label: "CO₂ avoided", value: item.co2Avoided, emoji: "🌍" },
        ].map((stat) => (
          <div
            key={stat.label}
            className="rounded-2xl p-3 text-center"
            style={{ background: "rgba(255,255,255,0.3)", border: "1px solid rgba(255,255,255,0.5)" }}
          >
            <div className="text-2xl mb-1">{stat.emoji}</div>
            <div className="text-white font-black text-sm leading-tight">{stat.value}</div>
            <div className="text-white/70 text-xs mt-0.5">{stat.label}</div>
          </div>
        ))}
      </div>

      {/* Cost comparison */}
      <div
        className="rounded-2xl p-4 mb-6"
        style={{ background: "rgba(255,255,255,0.2)", border: "1px solid rgba(255,255,255,0.4)" }}
      >
        <div className="flex justify-between items-center py-2 border-b border-white/20">
          <span className="text-white/80 text-sm font-semibold">Fast fashion price</span>
          <span className="text-white font-bold line-through opacity-60">{item.originalPrice}</span>
        </div>
        <div className="flex justify-between items-center py-2">
          <span className="text-white text-sm font-bold">Your DIY cost</span>
          <span className="font-black text-white">{item.diyPrice}</span>
        </div>
        <p className="text-white/60 text-xs mt-2 text-center">
          A bit more upfront, but yours will last 10–20× longer 💚
        </p>
      </div>

      {/* Buttons */}
      <div className="flex flex-col sm:flex-row gap-3">
        <button
          onClick={handleSave}
          className="flex-1 py-3 px-6 rounded-2xl font-bold text-white transition-all hover:scale-105 active:scale-95"
          style={{
            background: "linear-gradient(135deg, #d946a8, #a855f7)",
            boxShadow: "0 4px 20px rgba(217,70,168,0.4)",
            fontFamily: "'Nunito', sans-serif",
            fontWeight: 800,
          }}
        >
          ⭐ Save My Pattern
        </button>
        <button
          onClick={onReset}
          className="flex-1 py-3 px-6 rounded-2xl font-bold transition-all hover:scale-105 active:scale-95"
          style={{
            background: "rgba(255,255,255,0.25)",
            border: "2px solid rgba(255,255,255,0.6)",
            color: "white",
            fontFamily: "'Nunito', sans-serif",
            fontWeight: 800,
          }}
        >
          🔄 Transform Another
        </button>
      </div>
    </div>
  );
}

// ─── Breakdown Section ────────────────────────────────────────────────────────

interface BreakdownSectionProps {
  item: ItemTemplate;
  revealedCount: number;
  stepsVisible: boolean;
  onReset: () => void;
}

function BreakdownSection({ item, revealedCount, stepsVisible, onReset }: BreakdownSectionProps) {
  const allRevealed = revealedCount >= item.materials.length;

  return (
    <div className="relative z-10 w-full max-w-2xl mx-auto px-4 pb-16 flex flex-col gap-8">
      {/* Item header */}
      <div className="text-center">
        <div className="text-6xl mb-3">{item.emoji}</div>
        <h2
          className="text-3xl text-white mb-2"
          style={{ fontFamily: "'Pacifico', cursive", textShadow: "0 2px 12px rgba(100,0,80,0.4)" }}
        >
          {item.name}
        </h2>
        <div className="flex gap-3 justify-center flex-wrap">
          <span
            className="px-3 py-1 rounded-full text-sm font-bold text-red-300"
            style={{ background: "rgba(255,100,100,0.2)", border: "1px solid rgba(255,100,100,0.3)" }}
          >
            Fast fashion: {item.originalPrice}
          </span>
          <span
            className="px-3 py-1 rounded-full text-sm font-bold text-emerald-300"
            style={{ background: "rgba(52,211,153,0.2)", border: "1px solid rgba(52,211,153,0.3)" }}
          >
            DIY eco version: {item.diyPrice}
          </span>
        </div>
      </div>

      {/* Section heading */}
      <div className="text-center">
        <h3
          className="text-xl text-white font-bold mb-1"
          style={{ fontFamily: "'Nunito', sans-serif", textShadow: "0 1px 6px rgba(100,0,80,0.3)" }}
        >
          ☠️ Material Deconstruction → ✨ Eco Reconstruction
        </h3>
        <p className="text-white/70 text-sm" style={{ fontFamily: "'Nunito', sans-serif" }}>
          Every toxic shortcut, swapped for something beautiful and lasting.
        </p>
      </div>

      {/* Material swap cards */}
      <div className="flex flex-col gap-4">
        {item.materials.map((mat, i) => (
          <MaterialSwapCard
            key={i}
            original={mat}
            eco={item.ecoMaterials[i]}
            visible={i < revealedCount}
            index={i}
          />
        ))}
      </div>

      {/* Divider */}
      {allRevealed && (
        <div className="flex items-center gap-4">
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.3)" }} />
          <span className="text-white text-xl">🪡</span>
          <div className="flex-1 h-px" style={{ background: "rgba(255,255,255,0.3)" }} />
        </div>
      )}

      {/* DIY Steps */}
      {allRevealed && (
        <div>
          <h3
            className="text-xl text-white font-bold mb-4 text-center"
            style={{ fontFamily: "'Nunito', sans-serif", textShadow: "0 1px 6px rgba(100,0,80,0.3)" }}
          >
            🧵 Your Step-by-Step DIY Guide
          </h3>
          <StepsList steps={item.steps} visible={stepsVisible} />
        </div>
      )}

      {/* Summary */}
      {stepsVisible && (
        <div
          className="transition-all duration-700"
          style={{ opacity: stepsVisible ? 1 : 0, transform: stepsVisible ? "translateY(0)" : "translateY(20px)" }}
        >
          <SummaryPanel item={item} onReset={onReset} />
        </div>
      )}
    </div>
  );
}

// ─── CSS Keyframes Injection ──────────────────────────────────────────────────

const KEYFRAMES = `
@keyframes sparkle-twinkle {
  0%, 100% { opacity: 0.2; transform: scale(0.7) rotate(0deg); }
  50% { opacity: 1; transform: scale(1.2) rotate(20deg); }
}
@keyframes holographic-shift {
  0% { background-position: 0% 50%; }
  100% { background-position: 300% 50%; }
}
@keyframes wand-float {
  0%, 100% { transform: translateY(0) rotate(-5deg); }
  50% { transform: translateY(-10px) rotate(5deg); }
}
@keyframes wand-spin {
  0% { transform: rotate(0deg) scale(1); }
  25% { transform: rotate(90deg) scale(1.1); }
  50% { transform: rotate(180deg) scale(1); }
  75% { transform: rotate(270deg) scale(1.1); }
  100% { transform: rotate(360deg) scale(1); }
}
`;

function InjectKeyframes() {
  useEffect(() => {
    const style = document.createElement("style");
    style.textContent = KEYFRAMES;
    document.head.appendChild(style);
    return () => style.remove();
  }, []);
  return null;
}

// ─── App ──────────────────────────────────────────────────────────────────────

type Phase = "idle" | "analyzing" | "breakdown";

export default function App() {
  const [phase, setPhase] = useState<Phase>("idle");
  const [url, setUrl] = useState("");
  const [error, setError] = useState("");
  const [progress, setProgress] = useState(0);
  const [item, setItem] = useState<ItemTemplate | null>(null);
  const [revealedCount, setRevealedCount] = useState(0);
  const [stepsVisible, setStepsVisible] = useState(false);
  const progressRef = useRef<ReturnType<typeof setInterval> | null>(null);

  const handleSubmit = () => {
    const trimmed = url.trim();
    if (!trimmed) {
      setError("Please paste a product URL first ✨");
      return;
    }
    setError("");
    setProgress(0);
    setRevealedCount(0);
    setStepsVisible(false);
    const detected = detectTemplate(trimmed);
    setItem(detected);
    setPhase("analyzing");

    // Simulate progress
    let p = 0;
    progressRef.current = setInterval(() => {
      p += 2.5 + Math.random() * 3;
      if (p >= 100) {
        p = 100;
        clearInterval(progressRef.current!);
        setTimeout(() => {
          setPhase("breakdown");
          revealCards(detected.materials.length);
        }, 400);
      }
      setProgress(p);
    }, 120);
  };

  const revealCards = (total: number) => {
    let count = 0;
    const interval = setInterval(() => {
      count++;
      setRevealedCount(count);
      if (count >= total) {
        clearInterval(interval);
        setTimeout(() => setStepsVisible(true), 600);
      }
    }, 500);
  };

  const handleReset = () => {
    setPhase("idle");
    setUrl("");
    setError("");
    setProgress(0);
    setRevealedCount(0);
    setStepsVisible(false);
    setItem(null);
  };

  useEffect(() => {
    return () => {
      if (progressRef.current) clearInterval(progressRef.current);
    };
  }, []);

  return (
    <div className="min-h-screen w-full relative" style={{ fontFamily: "'Nunito', sans-serif" }}>
      <InjectKeyframes />
      <SparkleBackground />

      {/* Scrollable content layer */}
      <div className="relative z-10 min-h-screen">
        {phase === "idle" && (
          <HeroSection url={url} setUrl={setUrl} onSubmit={handleSubmit} error={error} />
        )}

        {phase === "analyzing" && (
          <AnalyzingAnimation progress={progress} />
        )}

        {phase === "breakdown" && item && (
          <BreakdownSection
            item={item}
            revealedCount={revealedCount}
            stepsVisible={stepsVisible}
            onReset={handleReset}
          />
        )}
      </div>
    </div>
  );
}
